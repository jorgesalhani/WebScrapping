import requests

def google_get():
    return requests.get("http://www.google.com")