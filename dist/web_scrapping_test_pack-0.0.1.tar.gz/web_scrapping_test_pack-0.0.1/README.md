# Web Scrapping Pack 0.0

Simple package to web scrapping studies