from ..src.webscrappin  g import 

def test_request_ok():
    res = auth_google.google_get()
    assert res.status_code == 200
