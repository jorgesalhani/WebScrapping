import sys 
sys.path.append("./")

from webdriver.firefox_profile import FirefoxProfile
import os

def health_check_profile():
    profile = FirefoxProfile()
    assert profile.username == 'jorge'
    # full_path = 'C:\\Users\\{}\\AppData\\Roaming\\Mozilla\\Firefox\\Profiles'.format(profile.username)
    # entries = os.listdir(full_path)
    # print(entries)
    # assert 1 == 1